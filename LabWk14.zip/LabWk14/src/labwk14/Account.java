/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labwk14;

import java.util.Date;
public class Account {
    
    private int id;
    private double balance;
    private double annualInterestRate;
    private Date dateCreated;
    
    
    
    Account(){
        id = 0;
        balance = 0;
        annualInterestRate = 0;
        dateCreated = new Date();
        }
    
    Account(int newId, double newBalance){
        id = newId;
        balance = newBalance;
        dateCreated = new Date();

    }
    
    public int getId(){
    
        return id;
}
    
    public void setId(int newId){
        
        id = newId;
    }
    
    public double getBalance(){
        
        return balance;
    }
    
    public void setBalance(double newBalance){
        
        balance = newBalance;
    }
    
    public double getAnnualInterestRate(){
        
        return annualInterestRate;
    }
    
    public void setAnnualInterestRate(double newAnnualInterestRate){
        
        annualInterestRate = newAnnualInterestRate / 100;
    }
    
    public Date getDateCreated(){
        
        return dateCreated;
    }
    
    public double getMonthlyInterestRate(){
        double monthlyInterestRate;
        
        monthlyInterestRate = annualInterestRate / 12;
        
        return monthlyInterestRate;
        
    }
    
    public double getMonthlyInterest(){
        double monthlyInterest;
        
        monthlyInterest = balance * (annualInterestRate / 12);
        
        return monthlyInterest;
    }
    
    public void withdraw(double take){
        
        balance -= take;
        
    }
    
    public void deposit(double put){
        
        balance += put;
    }
    
}
