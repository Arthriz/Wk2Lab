/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labwk14;

import java.util.Scanner;

/**
 *
 * @author gamer
 */
public class LabWk14 {

     
    
    public static void main(String[] args) {
        
        Scanner input = new Scanner (System.in);
        
        int goAgain = 1;
        int option = 0;
        
        for (int i = 0; i < 2; i++){
            
            System.out.println("Please enter an account ID and Balance.");
            
            Account account1 = new Account (input.nextInt(),input.nextDouble());
            
            account1.setAnnualInterestRate(4.5);
            
            for (int j = 0; j < 2; j++){
            
            System.out.println("______________________________");
            System.out.println("What would you like to do?");
            System.out.println("Withdraw: Enter 1");
            System.out.println("Deposit: Enter 2");
            System.out.println("Print Info: Enter 3");
            System.out.println("Stop: Enter 4");
            option = input.nextInt();
            
            if (option == 1){
                System.out.println("______________________________");
                System.out.println("How much would you like to withdraw?");
                account1.withdraw(input.nextDouble());
                j--;
            }else if(option == 2){
                System.out.println("______________________________");
                System.out.println("How much would you like to deposit?");
                account1.deposit(input.nextDouble());
                j--;
            }else if(option == 3){
                System.out.println("______________________________");
                System.out.println("Balance: " + account1.getBalance());
                System.out.println("Monthly Interest Rate: " + 
                        account1.getMonthlyInterest());
                System.out.println("Date Created: " + 
                        account1.getDateCreated());
                j--;
            }else if (option == 4){
                j++;
            }
            }
            
            
       /* Account account1 = new Account(1122,20000);
        
        account1.setAnnualInterestRate(4.5);
        
        account1.withdraw(2500);
        
        account1.deposit(3000);
        
        System.out.println("Balance: " + account1.getBalance());
        System.out.println("Monthly Interest Rate: " + 
                account1.getMonthlyInterest());
        System.out.println("Date Created: " + account1.getDateCreated());*/
        
       System.out.println("______________________________");
        System.out.println("If you would not like to create a new account " +  
                "enter 0.");
        goAgain = input.nextInt();
        System.out.println("______________________________");
        
        if (goAgain != 0)
            i--;
        else i ++;
        }
        
        
    }
    
}
